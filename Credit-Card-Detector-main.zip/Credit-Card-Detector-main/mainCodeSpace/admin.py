from django.contrib import admin
from .models import Attempts

# Register your models here.

admin.site.register(Attempts)